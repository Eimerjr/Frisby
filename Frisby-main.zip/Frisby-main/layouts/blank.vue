<template>
  <v-app>
    <nuxt/>
  </v-app>
</template>
