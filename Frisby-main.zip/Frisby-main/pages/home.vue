<template>
    <div>
        <h1>Bienvenidos!</h1>
         <img src="https://carloscortes.com.co/wp-content/uploads/2019/10/Logo-del-pollo-frisby-1024x448.jpg" alt="Frisby"> 
    </div>
</template>