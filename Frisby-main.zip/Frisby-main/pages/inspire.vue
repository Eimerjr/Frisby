<template>
  <div>Pag inspire</div>
</template>
